﻿namespace GrabnBite.DTOs.Cart
{
    public class UpdateCartItemDto
    {
        public int Quantity { get; set; }
    }
}